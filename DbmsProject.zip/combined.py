import streamlit as st
import mysql.connector
import time
import threading

# Dictionary to store login attempts
login_attempts = {}
# wishlist_items = []
# # Function to add items to the wishlist
# def add_to_wishlist(customer_id, item_id):
#     # Connect to MySQL database
#     connection = mysql.connector.connect(
#         host="localhost", user="root", password="password", database="BlinkBasket"
#     )
#     cursor = connection.cursor()

#     # Execute SQL query to add item to the wishlist
#     cursor.execute(
#         "INSERT INTO wishlist (customer_id, item_id) VALUES (%s, %s)",
#         (customer_id, item_id),
#     )
#     connection.commit()

#     # Close cursor and connection
#     cursor.close()
#     connection.close()


# Function to fetch wishlist items for a customer
# def fetch_wishlist_items(customer_id):
#     # Connect to MySQL database
#     connection = mysql.connector.connect(
#         host="localhost", user="root", password="password", database="BlinkBasket"
#     )
#     cursor = connection.cursor()

#     # Execute SQL query to fetch wishlist items for the customer
#     cursor.execute(
#         """
#         SELECT i.product_name 
#         FROM wishlist w
#         INNER JOIN item i ON w.item_id = i.item_id
#         WHERE w.customer_id = %s
#     """,
#         (customer_id,),
#     )
#     wishlist_items = cursor.fetchall()

#     # Close cursor and connection
#     cursor.close()
#     connection.close()

#     return wishlist_items

# Initialize wishlist_items list
if "wishlist_items" not in st.session_state:
    st.session_state.wishlist_items = []

# Function to add items to the wishlist
def add_to_wishlist(item_name):
    # Append the item to the wishlist
    st.session_state.wishlist_items.append(item_name)

# Function to fetch wishlist items
def fetch_wishlist_items():
    return st.session_state.wishlist_items


# Function to fetch wishlist items for a customer
# def fetch_wishlist_items():
#     global wishlist_items
#     print("fetch")
#     print(wishlist_items)
#     return wishlist_items

# Function to check if email is already registered
def check_email(email):
    # Connect to MySQL database
    connection = mysql.connector.connect(
        host="localhost", user="root", password="password", database="BlinkBasket"
    )
    cursor = connection.cursor()

    # Execute SQL query to check if email exists
    cursor.execute("SELECT * FROM customer WHERE name = %s", (email,))
    result = cursor.fetchone()

    # Close cursor and connection
    cursor.close()
    connection.close()

    return result is not None


# Function to update the database with new user information
def update_database(name, password, location, phone):
    # Connect to MySQL database
    connection = mysql.connector.connect(
        host="localhost", user="root", password="password", database="BlinkBasket"
    )

    cursor = connection.cursor(dictionary=True)

    # Execute SQL query to insert new user
    cursor.execute(
        "INSERT INTO profile (phone_no, address) VALUES (%s, %s)", (phone, location)
    )
    cursor.execute(
        "INSERT INTO customer (profile_id, name, password) VALUES (%s, %s, %s)",
        (cursor.lastrowid, name, password),
    )
    customer_id = cursor.lastrowid
    cursor.execute(
        "SELECT inventory_id, location - %s as distance FROM inventory ORDER BY distance ASC LIMIT 1;",
        (location,),
    )
    closest_inventory = cursor.fetchone()
    if closest_inventory:
        cursor.execute(
            "UPDATE customer SET inventory_id = %s WHERE customer_id = %s",
            (closest_inventory["inventory_id"], customer_id),
        )
        st.session_state.inventory_id = closest_inventory["inventory_id"]
    # Commit changes and close cursor and connection
    connection.commit()
    cursor.close()
    connection.close()


# Function to check if email and password match
def check_credentials(email, password):
    if email in login_attempts and login_attempts[email]["attempts"] >= 3:
        # If login attempts exceed 3, block login for 30 seconds
        if time.time() - login_attempts[email]["timestamp"] < 30:
            st.error("Too many login attempts. Please try again later.")
            return False

    # Connect to MySQL database
    connection = mysql.connector.connect(
        host="localhost", user="root", password="password", database="BlinkBasket"
    )
    cursor = connection.cursor(dictionary=True)

    # Execute SQL query to check if email and password match
    cursor.execute(
        "SELECT * FROM customer WHERE name = %s AND password = %s", (email, password)
    )
    result = cursor.fetchone()

    # Close cursor and connection
    cursor.close()
    connection.close()

    if result is not None:
        # Reset login attempts upon successful login
        if email in login_attempts:
            del login_attempts[email]
        st.session_state.customer_id = result["customer_id"]
        st.session_state.inventory_id = result["inventory_id"]
        return True
    else:
        # Increment login attempts
        if email in login_attempts:
            login_attempts[email]["attempts"] += 1
        else:
            login_attempts[email] = {"attempts": 1, "timestamp": time.time()}
        return False


# Function to check if employee ID and name match
def check_employee(employee_id, name):
    # Connect to MySQL database
    connection = mysql.connector.connect(
        host="localhost", user="root", password="password", database="BlinkBasket"
    )
    cursor = connection.cursor()

    # Execute SQL query to check if employee ID and name match
    cursor.execute(
        "SELECT * FROM employee WHERE employee_id = %s AND name = %s",
        (employee_id, name),
    )
    result = cursor.fetchone()

    # Close cursor and connection
    cursor.close()
    connection.close()

    return result is not None


def get_products():
    # Connect to MySQL database
    connection = mysql.connector.connect(
        host="localhost", user="root", password="password", database="BlinkBasket"
    )
    cursor = connection.cursor(dictionary=True)

    # Execute SQL query to fetch items
    cursor.execute(
        "SELECT product_name, COUNT(*) AS product_count FROM item WHERE inventory_id=%s AND availability = true GROUP BY product_name;",
        (st.session_state.inventory_id,),
    )
    products = cursor.fetchall()  # Fetch all items

    # Close cursor and connection
    cursor.close()
    connection.close()

    return products


def create_customer_cart(customer_id):
    # Connect to MySQL database
    connection = mysql.connector.connect(
        host="localhost", user="root", password="password", database="BlinkBasket"
    )
    cursor = connection.cursor()
    # Execute SQL query to fetch items
    cursor.execute(
        "INSERT INTO cart (customer_id, name) VALUES (%s, %s)", (customer_id, "Cart")
    )
    cart_id = cursor.lastrowid
    # Close cursor and connection
    connection.commit()
    cursor.close()
    connection.close()
    return cart_id


def get_product_counts_in_cart(cart_id):
    # Connect to MySQL database
    connection = mysql.connector.connect(
        host="localhost", user="root", password="password", database="BlinkBasket"
    )
    cursor = connection.cursor(dictionary=True)
    # Execute SQL query to fetch items
    cursor.execute(
        "SELECT product_name, COUNT(item_id) as count FROM item WHERE item_id IN (SELECT ci.item_id FROM cart_item ci WHERE ci.cart_id = %s) GROUP BY product_name;",
        (cart_id,),
    )
    product_counts = cursor.fetchall()
    # Close cursor and connection
    cursor.close()
    connection.close()
    return {row["product_name"]: row["count"] for row in product_counts}


# Customer page layout
def customer_page():
    st.title("Customer Page")
    if "cart_id" not in st.session_state:
        st.session_state.cart_id = create_customer_cart(st.session_state.customer_id)
    product_counts = get_product_counts_in_cart(st.session_state.cart_id)

    # Boxes representing products
    products = get_products()
    for product in products:
        with st.container(border=True):
            st.write(f"### {product['product_name']}")

            # Quantity selection
            col1, col2 = st.columns([1, 4])
            with col1:
                st.image("https://via.placeholder.com/150")

            with col2:
                with st.container():
                    # Create a separate variable to hold the quantity value
                    quantity = st.number_input(
                        f"Quantity",
                        min_value=0,
                        max_value=product["product_count"],
                        step=1,
                        value=product_counts.get(product["product_name"], 0),
                        key=f"{product}_quantity",
                    )

                    st.button(
                        f"Update cart",
                        key=f"{product['product_name']}_add_to_cart",
                        on_click=add_product_to_cart,
                        args=[product["product_name"], quantity],
                    )

                    # Add to wishlist button
                    if st.button(
                        f"Add to Wishlist",
                        key=f"{product['product_name']}_add_to_wishlist",
                        on_click=add_to_wishlist,
                        args=[product["product_name"]],
                    ):
                        st.success(f"{product['product_name']} added to wishlist!")

    # Box showing items added to cart
    st.sidebar.title("Cart")
    for product, quantity in product_counts.items():
        st.sidebar.write(f"- {product} (Quantity: {quantity})")

    # Order now button
    if st.sidebar.button(
        "Order Now", disabled=getattr(st.session_state, "disable_order", False) or len(product_counts) == 0
    ):
        st.sidebar.success("Order placed successfully!")
        st.switch_page("pages/review_order.py")

    # Wishlist section
    st.sidebar.title("Wishlist")
    # wishlist_item = fetch_wishlist_items()
    # print(wishlist_items)
    wishlist_items = fetch_wishlist_items()
    for item in wishlist_items:
        st.sidebar.write(item)

    st.sidebar.title("Settings")
    if st.sidebar.button("View order history", key="view_order_history"):
        st.switch_page("pages/order_history.py")

def add_product_to_cart(product_name, quantity):
    # Connect to MySQL database
    connection = mysql.connector.connect(
        host="localhost", user="root", password="password", database="BlinkBasket"
    )
    cursor = connection.cursor(dictionary=True)
    # Execute SQL query to fetch items
    cursor.execute(
        "SELECT item_id FROM item WHERE product_name = %s AND availability = true AND inventory_id = %s LIMIT %s",
        (product_name, st.session_state.inventory_id, quantity),
    )
    items = cursor.fetchall()
    item_ids = [item["item_id"] for item in items]
    enough_items = len(items) == quantity
    if enough_items:
        cursor.execute(
            "DELETE c FROM cart_item c NATURAL JOIN item i WHERE cart_id = %s AND i.product_name = %s",
            (st.session_state.cart_id, product_name),
        )
        if quantity > 0:
            cart_item_values = ", ".join(
                f"({st.session_state.cart_id}, {item_id})"
                for item_id in item_ids[:quantity]
            )
            cursor.execute(
                f"INSERT INTO cart_item (cart_id, item_id) VALUES {cart_item_values};"
            )
        connection.commit()
    cursor.close()
    connection.close()
    return enough_items

def Add_item_in_inventory(inventory_id,product_name,price):
    # Connect to MySQL database
    connection = mysql.connector.connect(
        host="localhost", user="root", password="password", database="BlinkBasket"
    )
    cursor = connection.cursor(dictionary=True)
    cursor.execute(cursor.execute("""
    INSERT INTO item (inventory_id, vendor_id, product_name, availability, threshold_quantity, expiry_date, price)
    VALUES (%s, 2, %s, TRUE, 0, "2025-05-20", %s)""", (inventory_id, product_name, price))) 
    connection.commit()   
    cursor.close()
    connection.close()


# Fetch customer details associated with the inventory managed by the employee
def fetch_customer_details(employee_id):
    # Connect to MySQL database
    connection = mysql.connector.connect(
        host="localhost", user="root", password="password", database="BlinkBasket"
    )
    cursor = connection.cursor()

    # Execute SQL query to fetch customer details associated with the inventory managed by the employee
    cursor.execute(
        """
        SELECT c.customer_id, c.name , t.created_time
        FROM customer c , employee e , cart t
        WHERE e.employee_id = %(employee_id)s and c.inventory_id = e.employee_id and t.customer_id = c.customer_id
    """,
        {"employee_id": employee_id},
    )

    customer_details = cursor.fetchall()

    # Close cursor and connection
    cursor.close()
    connection.close()

    return customer_details


# Fetch cart items for a specific customer
def fetch_cart_items(customer_id):
    # Connect to MySQL database
    connection = mysql.connector.connect(
        host="localhost", user="root", password="password", database="BlinkBasket"
    )
    cursor = connection.cursor()

    # Execute SQL query to fetch cart items for the customer
    cursor.execute(
        """
        SELECT its.product_name 
        FROM cart_item ct
        INNER JOIN cart c ON ct.cart_id = c.cart_id
        INNER JOIN item its ON ct.item_id = its.item_id
        WHERE c.customer_id = %s
    """,
        (customer_id,),
    )
    cart_items = cursor.fetchall()

    # Close cursor and connection
    cursor.close()
    connection.close()

    return cart_items


# Function to clean up login attempts after 30 seconds
def cleanup_attempts():
    while True:
        current_time = time.time()
        for email, attempt_info in list(login_attempts.items()):
            if current_time - attempt_info["timestamp"] >= 30:
                del login_attempts[email]
        time.sleep(1)  # Check every 5 seconds


# Start cleanup thread
cleanup_thread = threading.Thread(target=cleanup_attempts)
cleanup_thread.start()

def update_vendor_database(name, password, rating, contact, gst_number, location):
    # Connect to MySQL database
    connection = mysql.connector.connect(
        host="localhost", user="root", password="password", database="BlinkBasket"
    )

    cursor = connection.cursor(dictionary=True)

    # Execute SQL query to insert new vendor
    cursor.execute(
        "INSERT INTO vendor (name, password, rating, contact, gst_number, location) VALUES (%s, %s, %s, %s, %s, %s)",
        (name, password, rating, contact, gst_number, location),
    )

    # Commit changes and close cursor and connection
    connection.commit()
    cursor.close()
    connection.close()

def check_vendor_email(email):
    # Connect to MySQL database
    connection = mysql.connector.connect(
        host="localhost", user="root", password="password", database="BlinkBasket"
    )
    cursor = connection.cursor()

    # Execute SQL query to check if email exists for vendor
    cursor.execute("SELECT * FROM vendor WHERE name = %s", (email,))
    result = cursor.fetchone()

    # Close cursor and connection
    cursor.close()
    connection.close()

    return result is not None

def check_credentials_vendor(email, password):
    if email in login_attempts and login_attempts[email]["attempts"] >= 3:
        # If login attempts exceed 3, block login for 30 seconds
        if time.time() - login_attempts[email]["timestamp"] < 30:
            st.error("Too many login attempts. Please try again later.")
            return False

    # Connect to MySQL database
    connection = mysql.connector.connect(
        host="localhost", user="root", password="password", database="BlinkBasket"
    )
    cursor = connection.cursor(dictionary=True)

    # Execute SQL query to check if email and password match
    cursor.execute(
        "SELECT * FROM vendor WHERE name = %s AND password = %s", (email, password)
    )
    result = cursor.fetchone()

    # Close cursor and connection
    cursor.close()
    connection.close()

    if result is not None:
        # Reset login attempts upon successful login
        if email in login_attempts:
            del login_attempts[email]
        
        return True
    else:
        # Increment login attempts
        
        return False


# Main function to run the Streamlit app
def main():
    if 'coupons' in st.session_state:
        del st.session_state.coupons
    if 'editing_coupons' in st.session_state:
        del st.session_state.editing_coupons
    if 'delivery_instructions' in st.session_state:
        del st.session_state.delivery_instructions
    if '_items' in st.session_state:
        del st.session_state._items
    if 'requested_page' in st.session_state:
        del st.session_state.requested_page
    # Set page title and favicon
    st.set_page_config(page_title="Login and Signup", page_icon=":lock:")

    # Navbar
    st.sidebar.title("Navigation")
    user_type = st.sidebar.radio("User Type", ("Customer", "Inventory manager", "Vendor"))

    if user_type == "Inventory manager":
        # Set app title
        st.title("Manager Dashboard")
        employee_id = st.number_input("Employee ID")
        name = st.text_input("Name")

        if "current_page" not in st.session_state:
            st.session_state.current_page = "main"

        if st.button("Proceed", key="proceed_button"):
            if check_employee(employee_id, name):
                st.session_state.current_page = "main"
                st.success("Employee verified! Fetching customer details...")

            else:
                st.error("Invalid employee ID or name. Please try again.")

        if st.session_state.current_page == "main":
            # Button to add an item
            if st.button("Add Item", key="add_item_button"):
                st.session_state.current_page = "add_item"

            # Button to show customer details
            if st.button("Customer details", key="show_customer_details"):
                st.session_state.current_page = "customer_details"

        if st.session_state.current_page == "add_item":
            st.title("Add Item")
            product_name = st.text_input("Product Name")
            price = st.number_input("Price")
            # expiry_date = st.text_input("Expiry Date")

            if st.button("Add", key="add_button"):
                Add_item_in_inventory(employee_id, product_name, price)
                st.success(f"{product_name} successfully added to inventory!")
                st.session_state.current_page = "main"

        if st.session_state.current_page == "customer_details":
            # Fetch customer details associated with the inventory managed by the employee
            customer_details = fetch_customer_details(employee_id)

            if customer_details:
                st.write(f"Employee ID: {employee_id}")
                st.write("## Customer Details")
                for customer in customer_details:
                    cart_items = fetch_cart_items(customer[0])
                    st.write(f"Customer ID: {customer[0]}")
                    st.write(f"Name: {customer[1]}")
                    st.write(f"Created Time: {customer[2]}")
                    st.write(f"Cart items: {cart_items}")
                    st.write("---")
                st.session_state.current_page = "main"

                
    elif user_type == "Vendor":
        # Set app title
        st.title("Vendor Login and Signup")

        st.subheader("Vendor Options")
        option = st.selectbox("Select an option", ["", "Signup", "Login"])

        if option == "Signup":
            st.subheader("Signup")
            email = st.text_input("Name")
            password = st.text_input("Password", type="password")
            confirm_password = st.text_input("Confirm P assword", type="password")
        
            contact = st.text_input("Contact", max_chars=10)
            gst_number = st.text_input("GST Number")
            location = st.text_input("Location")

            if st.button("Register", key="register_button"):
                if password == confirm_password:
                    if not check_vendor_email(email):
                        update_vendor_database(email, password, 0, contact, gst_number, location)
                        st.success("Registration successful!")
                    else:
                        st.error("User already registered!")
                else:
                    st.error("Passwords do not match!")

        elif option == "Login":
            st.subheader("Login")
            email = st.text_input("Name")
            password = st.text_input("Password", type="password")

            if st.button("Login", key="login_button"):
                if check_credentials_vendor(email, password):
                    st.success("Login successful!")
                   
                else:
                    st.error("Invalid email or password. Please retry.")

    else:
        # Set app title
        st.title("Login and Signup")
        st.subheader("Customer Options")
        option = st.selectbox("Select an option", ["", "Signup", "Login"])

        if option == "Signup":
            st.subheader("Signup")
            email = st.text_input("Name")
            password = st.text_input("Password", type="password")
            confirm_password = st.text_input("Confirm Password", type="password")
            location = st.text_input("Location")
            phone = st.text_input("Phone")

            if st.button("Register", key="register_button"):
                if password == confirm_password:
                    if not check_email(email):
                        update_database(email, password, location, phone)
                        st.success("Registration successful!")
                    else:
                        st.error("User already registered!")
                else:
                    st.error("Passwords do not match!")

        elif option == "Login":
            st.subheader("Login")
            email = st.text_input("Name")
            password = st.text_input("Password", type="password")

            if st.button("Login", key="login_button"):
                if check_credentials(email, password):
                    st.success("Login successful!")
                    st.session_state.logged_in = (
                        True  # Set session state variable to indicate logged in status
                    )
                    if "cart_id" in st.session_state:
                        del st.session_state.cart_id
                else:
                    st.error("Invalid email or password. Please retry.")

    # Render customer page if logged in
    if getattr(st.session_state, "logged_in", False):
        customer_page()


# Run the app
if __name__ == "__main__":
    main()
