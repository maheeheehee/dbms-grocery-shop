import streamlit as st
import mysql.connector
import datetime as dt

STYLESHEET = '''
<style class="custom">
.element-container:has(> .stMarkdown .custom) {
    display: none;
}

.stCheckbox p {
    font-size: 20px;
    margin: 0px 10px 10px 10px;
}
</style>
'''

def main():
    global connection
    connection = mysql.connector.connect(
        host='localhost',
        user='root',
        password='password',
        database='BlinkBasket',   
    )
    connection.close()

    if "requested_page" not in st.session_state:
        st.session_state.requested_page = None
    st.session_state.fields = [""]
    st.set_page_config(page_title='Place order')
    st.title('Complete payment and place your order')

    if 'payment_method' not in st.session_state:
        st.session_state.payment_method = {'payment_method_id': None}

    st.markdown(STYLESHEET, unsafe_allow_html=True)

    if st.session_state.payment_method['type'] != 'COD':
        with st.container(border=True):
            st.caption("Login details")
            if st.session_state.payment_method['type'] == 'UPI':
                upi_number = st.text_input('UPI number', placeholder="Enter your UPI number")
                st.session_state.fields = [upi_number]
            elif st.session_state.payment_method['type'] == 'Bank Transfer':
                account_number = st.text_input('Account number', placeholder="Enter your account number")
                account_password = st.text_input('Password', placeholder="Enter your password", type="password")
                comments = st.text_input('Comments')
                st.session_state.fields = [account_number, account_password]
            elif st.session_state.payment_method['type'] == 'Online Payment':
                account_number = st.text_input('Account number', placeholder="Enter your account number")
                account_password = st.text_input('Password', placeholder="Enter your password", type="password")
                st.session_state.fields = [account_number, account_password]
    else:
        st.session_state.fields = []
    with st.container(border=True):
        st.caption("Payment details")
        st.markdown(f"**Amount:** ₹{st.session_state.total}")
    button_columns = st.columns(2)
    with button_columns[0]:
        st.button('Back', key='back', type='secondary', use_container_width=True, on_click=lambda: request_page('pages/payment_method.py'))
    with button_columns[1]:
        st.button('Proceed with payment', key='proceed-with-payment', type='primary', use_container_width=True, disabled=not check_details(), on_click=lambda: request_page('pages/order_summary.py') or update_database())
    
    if st.session_state.requested_page:
        page = st.session_state.requested_page
        st.session_state.requested_page = None
        st.switch_page(page)

def fetchall(statement, *args, **kwargs):
    connection.connect()
    cursor = connection.cursor(dictionary=True)
    cursor.execute(statement, *args, **kwargs)
    result = cursor.fetchall()
    connection.close()
    return result

order_insertion_query = '''
INSERT INTO orderr (cart_id, customer_id, created_time, instructions, subtotal, delivery_charge, amount_saved, total)
VALUES 
(%(cart_id)s, %(customer_id)s, %(created_time)s, %(delivery_instructions)s, %(subtotal)s, %(delivery_charge)s, %(amount_saved)s, %(total)s);'''
coupon_application_query = '''
UPDATE coupon
SET order_id = %(order_id)s
WHERE coupon_id = %(coupon_id)s;'''
payment_insertion_query = '''
INSERT INTO payment (payment_method_id, amount, start_time, end_time, status)
VALUES
(%(payment_method_id)s, %(amount)s, %(start_time)s, %(end_time)s, %(status)s);'''
payment_linking_query = '''
UPDATE orderr
SET payment_id = %(payment_id)s
WHERE order_id = %(order_id)s;'''
mark_items_as_sold = '''
UPDATE item
SET sold = TRUE
WHERE item_id IN (
    SELECT item_id
    FROM cart_item
    WHERE cart_id = %(cart_id)s
)'''
def update_database():
    connection.connect()
    cursor = connection.cursor(dictionary=True)
    cursor.execute(order_insertion_query, {
        'cart_id': st.session_state.cart_id,
        'customer_id': st.session_state.customer_id,
        'created_time': dt.datetime.now(),
        'delivery_instructions': st.session_state.delivery_instructions,
        'subtotal': st.session_state.subtotal,
        'delivery_charge': st.session_state.delivery_charge,
        'amount_saved': 0,
        'total': st.session_state.subtotal + st.session_state.delivery_charge,
    })
    st.session_state.order_id = cursor.lastrowid
    for coupon_id in st.session_state.coupons:
        cursor.execute(coupon_application_query, {
            'order_id': st.session_state.order_id,
            'coupon_id': coupon_id,
        })
    cursor.execute(payment_insertion_query, {
        'payment_method_id': st.session_state.payment_method['payment_method_id'],
        'amount': st.session_state.total,
        'start_time': dt.datetime.now(),
        'end_time': dt.datetime.now(),
        'status': 'Completed',
    })
    st.session_state.payment_id = cursor.lastrowid
    cursor.execute(payment_linking_query, {
        'payment_id': st.session_state.payment_id,
        'order_id': st.session_state.order_id,
    })
    cursor.execute(mark_items_as_sold, {
        'cart_id': st.session_state.cart_id,
    })
    connection.commit()
    connection.close()

def request_page(page):
    st.session_state.requested_page = page

def check_details():
    return not any(field.strip() == "" for field in st.session_state.fields)

if __name__ == '__main__':
    main()