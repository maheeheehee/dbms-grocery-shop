import streamlit as st
import mysql.connector

STYLESHEET = '''
<style class="custom">
.element-container:has(> .stMarkdown .custom) {
    display: none;
}

.stCheckbox p {
    font-size: 20px;
    margin: 0px 10px 10px 10px;
}
</style>
'''

def main():
    global connection
    connection = mysql.connector.connect(
        host='localhost',
        user='root',
        password='password',
        database='BlinkBasket',   
    )
    connection.close()

    if "requested_page" not in st.session_state:
        st.session_state.requested_page = None

    st.set_page_config(page_title='Choose payment method')
    st.title('Choose your payment method')

    if 'payment_method' not in st.session_state:
        st.session_state.payment_method = {'payment_method_id': None}

    st.markdown(STYLESHEET, unsafe_allow_html=True)

    with st.container(border=True):
        payment_methods = fetchall('SELECT * FROM payment_method;')
        for payment_method in payment_methods:
            st.checkbox(label=payment_method['name'] + " (" + payment_method['type'] + ")", value= st.session_state.payment_method['payment_method_id'] == payment_method['payment_method_id'], key=payment_method['payment_method_id'], on_change=_closure_toggle_method(payment_method))

    button_columns = st.columns(2)
    with button_columns[0]:
        st.button('Back', key='back', type='secondary', use_container_width=True, on_click=lambda: request_page('pages/review_order.py'))
    with button_columns[1]:
        st.button('Choose method', key='choose-method', type='primary', use_container_width=True, disabled=st.session_state.payment_method['payment_method_id'] == None, on_click=lambda: request_page('pages/payment.py'))

    if st.session_state.requested_page:
        page = st.session_state.requested_page
        st.session_state.requested_page = None
        st.switch_page(page)

def fetchall(statement, *args, **kwargs):
    connection.connect()
    cursor = connection.cursor(dictionary=True)
    cursor.execute(statement, *args, **kwargs)
    result = cursor.fetchall()
    connection.close()
    return result

def _closure_toggle_method(payment_method):
    def toggle_method():
        nonlocal payment_method
        if st.session_state.payment_method['payment_method_id'] == payment_method['payment_method_id']:
            st.session_state.payment_method = {'payment_method_id': None}
        else:
            st.session_state.payment_method = payment_method
    return toggle_method

def request_page(page):
    st.session_state.requested_page = page

if __name__ == '__main__':
    main()