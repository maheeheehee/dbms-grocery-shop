import streamlit as st
import mysql.connector

STYLESHEET = '''
<style class="custom">

div[data-testid="stHorizontalBlock"] div[data-testid="column"]:last-child:not(:has(.coupon)) p {
    text-align: right;
}

.total-label {
    font-size: 14px;
}

.element-container:has(> .stMarkdown .custom) {
    display: none;
}

.total-value:not([saved]) {
    color: gray;
}

div[data-testid="stVerticalBlockBorderWrapper"] div[data-testid="stHorizontalBlock"]:last-child div[data-testid="stMarkdownContainer"] .total-label {
    font-weight: bold;
    font-size: 17px;
}

div[data-testid="stVerticalBlockBorderWrapper"] div[data-testid="stHorizontalBlock"]:last-child div[data-testid="stMarkdownContainer"] .total-value {
    font-weight: bold;
    font-size: 14px;
}

div[data-testid="stVerticalBlockBorderWrapper"] div[data-testid="stHorizontalBlock"]:last-child .st-emotion-cache-eqffof .total-value {
    color: black;
}

div[data-testid="stVerticalBlockBorderWrapper"] div[data-testid="stHorizontalBlock"]:last-child .st-emotion-cache-cnbvxy .total-value {
    color: white;
}

div[data-testid="stVerticalBlockBorderWrapper"] div[data-testid="stHorizontalBlock"]:has(.coupon) div[data-testid="stVerticalBlockBorderWrapper"] {
    padding: 0px;
    margin: 0px 3px 0px 3px;
}

div[data-testid="stHorizontalBlock"]:has(.coupon) {
    gap: 0px;
}

div[data-testid="column"] > div[data-testid="stVerticalBlockBorderWrapper"] {
    display: flex;
}

div[data-testid="column"]:has(.coupon) div[data-testid="stVerticalBlockBorderWrapper"] div {
    display: initial;
}

# div[data-testid="stHorizontalBlock"]:has(.edit-marker) {
#     div[data-testid="column"]:has(button) * {
#         height: 100%;
#         vertical-align: middle;
#     }

#      div[data-testid="column"]:last-child {
#         button div {
#             display: table;
#             p {
#                 display: table-cell;
#                 text-align: center;
#                 font-size: 14px;
#             }
#         }
#         button:not(:hover):not(:active) {
#             color: rgb(255, 75, 75);
#             border-color: rgb(255, 75, 75);
#             border: 1px dashed;
#         }
#         button:active {
#             background-color: #ff6f4b;
#         }
#      }
# }

.coupon {
    background-image: url("data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='6' ry='6' stroke='%23FFFFFF69' stroke-width='3' stroke-dasharray='6%2c 8' stroke-dashoffset='1' stroke-linecap='butt'/%3e%3c/svg%3e");
    border-radius: 6px;
    width: auto !important;
    height: auto !important;
    margin: 2px;
    padding: 6px;
    line-height: 1.1rem;
}

div:has(.coupon) {
    border-radius: 6px;
}

.coupon-code, .coupon-desc {
    color: white;
}

.coupon-code {
    font-size: 1rem;
    font-weight: bold;
}

.coupon-desc {
    font-size: 0.7rem;
}

.table-caption {
    font-weight: bold;
    # color: gray;
}

</style>
'''

COUPON_COLORS = ["DeepPink", "Orange", "SteelBlue", "Purple", "BlueViolet"]
coupon_color_index = -1

COUPON_STYLE = '''
<style class="custom">
div[data-testid="column"]:has(.coupon{index}) div[data-testid="stVerticalBlockBorderWrapper"] {{
    background-color: color-mix(in srgb, {color}, white 20%);
}}
</style>
'''

# Main function to run the Streamlit app
def main():
    toggle_navbar(False)

    global connection
    connection = mysql.connector.connect(
        host='localhost',
        user='root',
        password='password',
        database='BlinkBasket',   
    )
    connection.close()

    # Set page title and favicon
    st.set_page_config(page_title='Order history')

    # Set app title
    st.title("Your order history")

    st.markdown(STYLESHEET, unsafe_allow_html=True)

    # Fetch all orders
    orders = fetchall('SELECT * FROM orderr WHERE customer_id = %(customer_id)s ORDER BY created_time DESC;', {'customer_id': st.session_state.customer_id})
    for i, order in enumerate(orders):
        render_order(order, first=i==0)
        if i == 0:
            st.button('Browse items', key='browse-items', type='primary', use_container_width=True, on_click=lambda: st.session_state.__delattr__('cart_id') or request_page('combined.py'))
            st.markdown('<hr style="margin: 0px" class="separator">', unsafe_allow_html=True)
    # pprint.pprint(items)

    # st.button('Browse items', key='browse-items', type='primary', use_container_width=True, on_click=lambda: st.session_state.__delattr__('cart_id') or request_page('combined.py'))  # ! Link to browse items

    if hasattr(st.session_state, 'requested_page') and st.session_state.requested_page:
        page = st.session_state.requested_page
        st.session_state.requested_page = None
        st.switch_page(page)

def render_order(order_info, first=False):
    order_id = order_info['order_id']
    created_time = order_info['created_time']
    items = fetchall('SELECT * FROM cart_item NATURAL JOIN item WHERE cart_id = %(cart_id)s;', {'cart_id': order_info['cart_id']})
    coupons = fetchall('SELECT * FROM coupon WHERE order_id = %(order_id)s;', {'order_id': order_id})
    payment = fetchall('SELECT * FROM payment WHERE payment_id = %(payment_id)s;', {'payment_id': order_info['payment_id']})[0]
    payment_method = fetchall('SELECT * FROM payment_method WHERE payment_method_id = %(payment_method_id)s;', {'payment_method_id': payment['payment_method_id']})[0]
    with st.expander(f"Order #{order_id} ordered at {created_time} ({order_info['status']})", expanded=first):
        with st.container(border=True):
            columns = st.columns([0.3, 0.5, 0.2])
            with columns[0]:
                st.markdown('<p class="table-caption">Item</p>', unsafe_allow_html=True)
            with columns[2]:
                st.markdown('<p class="table-caption">Price</p>', unsafe_allow_html=True)

            for item in items:
                render_item_row(item)


            if len(coupons):
                st.markdown('<hr style="margin: 0px">', unsafe_allow_html=True)
                st.markdown('<p class="table-caption coupons-caption" style="margin-bottom: 7px;">Coupons</p>', unsafe_allow_html=True)
                render_coupons(coupons)

            st.markdown('<hr style="margin: 0px" class="coupon-separator">', unsafe_allow_html=True)

            render_totalling_row("🧾 Subtotal", order_info['subtotal'])
            render_totalling_row("🛵 Delivery charge", order_info['delivery_charge'])
            render_totalling_row("💰 Amount saved", order_info['amount_saved'], True)
            render_totalling_row("Total", order_info['total'])

        with st.container(border=True):
            st.text_input('Delivery instructions', order_info['instructions'], disabled=True, key=f"delivery-instructions-{order_id}")

        with st.container(border=True):
            st.caption("Payment details")
            st.markdown(f"**Amount:** ₹{order_info['total']}")
            st.markdown(f"**Payment method:** {payment_method['name']} ({payment_method['type']})")
            st.markdown(f"**Payment status:** {payment['status']}")

def fetchall(statement, *args, **kwargs):
    connection.connect()
    cursor = connection.cursor(dictionary=True)
    cursor.execute(statement, *args, **kwargs)
    result = cursor.fetchall()
    connection.close()
    return result

def render_item_row(item):
    columns = st.columns([0.08, 0.2, 0.5, 0.2])
    with columns[0]:
        st.markdown(f'<p id="myPara" style="opacity: 0.4">#{item["item_id"]:03}</p>', unsafe_allow_html=True)
    with columns[1]:
        st.write(item['product_name'])
    with columns[3]:
        st.markdown(f'<code style="color: gray"> ₹{item["price"]} </code>', unsafe_allow_html=True)

def render_totalling_row(label, value, saved=False):
    columns = st.columns([0.3, 0.5, 0.2])
    with columns[0]:
        st.markdown(f'<p class="total-label">{label}</p>', unsafe_allow_html=True)
    with columns[2]:
        st.markdown(f'<code class="total-value" {"saved" if saved else ""}> ₹{value:.2f} </code>', unsafe_allow_html=True)

def render_coupons(coupons):
    columns = None
    for (i, coupon) in enumerate(coupons):
        if i % 3 == 0:
            columns = st.columns(3)
        with columns.pop(0):
            render_coupon_inner(coupon)

def calculate_coupon(amount, type):
    if type == "Flat":
        return amount
    else:
        return amount/100 * st.session_state.subtotal

def render_coupon_inner(coupon):
    st.markdown(COUPON_STYLE.format(index=coupon['coupon_id'], color=COUPON_COLORS[coupon['coupon_id'] % len(COUPON_COLORS)]), unsafe_allow_html=True)
    st.markdown(f'''
                        <p class="coupon coupon{coupon['coupon_id']}">
                            <span class="coupon-code">{coupon['code']}</span>
                            <br>
                            <span class="coupon-desc">{coupon['description']}</span>
                        </p>
            ''', unsafe_allow_html=True)

def toggle_navbar(target):
    target = "true" if target else "false"
    change = False
    with open(".streamlit/config.toml", "r") as file:
        if f"showSidebarNavigation = {target}" not in file.read():
            change = True
    if not change: return
    with open(".streamlit/config.toml", "w") as file:
        file.write(f'[client]\nshowSidebarNavigation = {target}')
    st.rerun()

def request_page(page):
    st.session_state.requested_page = page

# Run the app
if __name__ == '__main__':  
    main()
